package dao;

import java.util.List;

import javabean.User;

public interface IUserDao {
	public int add(User user);
	public List<User> QueryAll();
}
