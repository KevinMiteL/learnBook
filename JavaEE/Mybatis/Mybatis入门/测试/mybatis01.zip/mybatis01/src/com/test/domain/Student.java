package com.test.domain;


/*@Alias("stu")*/
public class Student {
	String stuname;
	int stuid;

	public String getStuname() {
		return stuname;
	}

	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

	public int getStuid() {
		return stuid;
	}

	public void setStuid(int stuid) {
		this.stuid = stuid;
	}


}
