package biz;

import java.util.List;

import javabean.User;

public interface StudentMapper {
	public List<User> QueryAll();
}
