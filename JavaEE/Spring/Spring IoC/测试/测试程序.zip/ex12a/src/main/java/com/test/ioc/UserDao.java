package com.test.ioc;

public interface UserDao {
	public void say();
}
