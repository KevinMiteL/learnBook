package com.test.ioc;

public class UserDaoImpl implements UserDao {
	public void say() {
		System.out.println("userDao say hello World ! XXX-XXX");
	}
}
