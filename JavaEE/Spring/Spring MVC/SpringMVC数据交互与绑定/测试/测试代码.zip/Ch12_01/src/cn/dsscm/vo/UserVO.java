package cn.dsscm.vo;

import java.util.List;

import cn.dsscm.pojo.User;
/**
 * 用户包装类
 */
public class UserVO {
	private List<User> users;
	public List<User> getUsers() {
		return users;
	}
	public void setUsers(List<User> users) {
		this.users = users;
	}
}
