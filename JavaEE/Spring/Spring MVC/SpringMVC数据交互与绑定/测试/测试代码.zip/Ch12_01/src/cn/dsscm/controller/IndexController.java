package cn.dsscm.controller;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cn.dsscm.pojo.User;
@Controller
public class IndexController{
	private Logger logger = Logger.getLogger(IndexController.class);
	
	/**
	 * 参数传递：controller to view -(ModelAndView)
	 * @param username
	 * @return
	 */
	@RequestMapping("/index1")
	public ModelAndView index(String username){
		logger.info("welcome! username: " + username);
		ModelAndView mView = new ModelAndView();
		mView.addObject("username", username);
		mView.setViewName("index");
		return mView;
	}
	
	/**
	 * 参数传递：controller to view -(Model)
	 * @param username
	 * @param model
	 * @return
	 */
	@RequestMapping("/index2")
	public String index(String username,Model model){
		logger.info("hello,SpringMVC! username: " + username);
		model.addAttribute("username", username);
		return "index";
	}
	
	@RequestMapping("/index3")
	public String index3(String username,Model model){
		logger.info("hello,SpringMVC! username: " + username);
		model.addAttribute("username", username);
		model.addAttribute(username);
		return "index";
	}
	
	@RequestMapping("/index4")
	public String index4(String username,Model model){
		logger.info("hello,SpringMVC! username: " + username);
		model.addAttribute("username", username);
		/**
		 * 默认使用对象的类型作为key：
		 * model.addAttribute("string", username)
		 * model.addAttribute("user", new User())
		 */
		model.addAttribute(username);
		User user = new User();
		user.setUsername(username);
		model.addAttribute("currentUser", user);
		model.addAttribute(user);
		return "index";
	}
	
	/**
	 * 参数传递：controller to view -(Map<String,Object>)
	 * @param username
	 * @param model
	 * @return
	 */
	@RequestMapping("/index5")
	public String index5(String username,Map<String, Object> model){
		logger.info("hello,SpringMVC! username: " + username);
		model.put("username", username);
		return "index";
	}

}

