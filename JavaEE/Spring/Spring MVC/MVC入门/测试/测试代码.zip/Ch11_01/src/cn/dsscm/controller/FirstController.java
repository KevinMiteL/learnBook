package cn.dsscm.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class FirstController implements Controller{
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)  {
        
		System.out.println("Hello,SpringMVC!"); //在控制台输出日志信息
        
        // 创建ModelAndView对象
        ModelAndView mav = new ModelAndView();
        
        // 向模型对象中添加数据
        mav.addObject("msg", "这是我的第一个Spring MVC程序!");
        mav.addObject("name", "XXX-学号！");
        
        // 设置逻辑视图名
        mav.setViewName("/WEB-INF/jsp/index.jsp");
        
        // 返回ModelAndView对象
       return mav;
	}
}

