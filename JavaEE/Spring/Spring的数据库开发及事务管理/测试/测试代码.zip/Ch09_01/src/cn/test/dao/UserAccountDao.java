package cn.test.dao;

import java.util.List;

import cn.test.pojo.UserAccount;

public interface UserAccountDao {
	// 添加
	public int addAccount(UserAccount userAccount);
	// 更新
	public int updateAccount(UserAccount userAccount);
	// 删除
	public int deleteAccount(int id);
	
	// 通过id查询
	public UserAccount findAccountById(int id);
	// 查询所有账户
	public List<UserAccount> findAllAccount();
}
